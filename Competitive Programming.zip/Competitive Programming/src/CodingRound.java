import java.util.*;
import java.io.*;

public class CodingRound
{
    static class FastReader
    {
        BufferedReader br;
        StringTokenizer st;

        public FastReader()
        {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        String next()
        {
            while(st==null || !st.hasMoreElements())
            {
                try
                {
                    st = new StringTokenizer(br.readLine());
                }
                catch(IOException e)
                {
                    e.printStackTrace();
                }
            }
            return st.nextToken();
        }

        int nextInt()
        {
            return Integer.parseInt(next());
        }

        String nextLine()
        {
            String str = "";

            try
            {
                str = br.readLine();
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return str;
        }
    }

    static long gcd(long a, long b)
    {
        if (a==0) return b;
        else return gcd(b%a,a);
    }

    static int fillWater(int fromm, int too, int target)
    {
        int f = fromm;
        int t = 0;
        int count = 1;
        while (f != target && t != target)
        {
            int temp = Math.min(f, too - t);

            t += temp;
            f -= temp;
            count++;

            if (f == target || t == target)
                break;

            if (f == 0)
            {
                f = fromm;
                count++;
            }

            if (t == too)
            {
                t = 0;
                count++;
            }
        }
        return count;
    }

    static int countMin(int b, int a, int c)
    {
        if (b > a)
        {
            b=b^a;
            a=a^b;
            b=b^a;
        }

        if (c > a)
            return -1;

        if ((c % gcd(a,b)) != 0)
            return -1;

        return Math.min(fillWater(a,b,c), fillWater(b,a,c));
    }

    public static void main(String[] args)
    {
        FastReader fr = new FastReader();

        int testcases = fr.nextInt();

        while (testcases -- > 0)
        {
            int a = fr.nextInt();
            int b = fr.nextInt();
            int c = fr.nextInt();

            if (c>Math.max(a,b) && ((c%a == 0) || (c%b == 0)))
            {
                System.out.println("Yes");
            }
            else
            {
                int var = countMin(b,a,c);

                if (var == -1) System.out.println("No");
                else System.out.println("Yes");
            }
        }
    }
}
