import java.util.ArrayList;
import java.util.*;
import java.util.LinkedList;

class Solution{
    public static void main(String[] args) {
        Scanner r = new Scanner(System.in);
        int testcases = r.nextInt();
        StringBuilder sb = new StringBuilder();
        while (testcases -- > 0){
            int n = r.nextInt();
            long x = r.nextLong();
            long y = r.nextLong();

            List<Long> list = new ArrayList<>();
            long sum = 0;
            int count = 0;
            boolean ff = false;
            boolean varCheck = false;
            for (int i=0;i<n;i++){
                long ele = r.nextLong();
                list.add(ele);
                sum+=ele;

                if (sum>=x&&sum<=y) ff = true;

                if (ele>=x && ele<=y) varCheck = true;

                if (ele>y) count++;
            }

            long tempSum = sum;

            if (sum<x) sb.append(-1).append("\n");
            else if (sum>y && count == n) sb.append(-1).append("\n");
            else if (ff) sb.append(0).append("\n");
            else{
                sum = 0;
                ff = false;

                for (int i=0;i<n;i++){
                    sum = 0;

                    ff = false;
                    for (int j=i;j<n;j++){
                        sum+=list.get(j);

                        if (sum>=x && sum<=y) {
                            ff = true;
                            break;
                        }
                    }
                    if (ff) break;

                    for (int j=0;j<i;j++) {
                        sum += list.get(j);

                        if (sum>=x && sum<=y){
                            ff = true;
                            break;
                        }
                    }

                    if (ff) break;
                }

                if (ff) sb.append(1).append("\n");
                else{

                }
            }
        }
        System.out.println(sb);
    }
}