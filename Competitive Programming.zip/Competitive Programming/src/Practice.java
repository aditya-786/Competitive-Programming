/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
public class Practice
{
    public static void main(String[] args) throws java.lang.Exception {
        try {
            Scanner sc = new Scanner(System.in);
            HashSet<String> set = new HashSet<>();
            while (sc.hasNext()){
                set.add(sc.nextLine());
            }
            // System.out.println(set);
            double totalMarks = 0;
            HashSet<String> s1 = new HashSet<>();
            HashSet<String> s2 = new HashSet<>();
            for (String str :
                    set) {
                String first = str.split("\\(([^)]+)\\)")[0];
                String last = str.split(".+\\(")[1];
                if (first.length() < 5) {
                    if (first.equals("ACov") || first.equals("BCov") || first.equals("CCov") ||
                            first.equals("DCov") || first.equals("ECov") || first.equals("FCov")) {
                        //totalMarks += 0.5;
                        s1.add(first);
                        //System.out.println(first);
                    }
                }
                if (last.length() < 3) {
                    if (last.equals("A)") || last.equals("B)") || last.equals("C)") || last.equals("D)") ||
                            last.equals("E)") || last.equals("F)")) {
                        //totalMarks += 0.5;
                        s2.add(last);
                        //System.out.println(last);
                    }
                }
            }

            totalMarks = s1.size()*0.5;
            totalMarks+=s2.size()*0.5;

            System.out.println(totalMarks);
        }catch (Exception e){}
        finally {
        }
    }

}
