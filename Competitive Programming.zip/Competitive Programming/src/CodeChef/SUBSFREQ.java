//package CodeChef;
//
//import java.io.*;
//import java.time.Period;
//import java.util.*;
//import java.math.*;
//
//class SUBSFREQ {
//    static class FastReader
//    {
//        BufferedReader br;
//        StringTokenizer st;
//
//        public FastReader()
//        {
//            br = new BufferedReader(new InputStreamReader(System.in));
//        }
//
//        String next()
//        {
//            while(st==null || !st.hasMoreElements())
//            {
//                try
//                {
//                    st = new StringTokenizer(br.readLine());
//                }
//                catch(IOException e)
//                {
//                    e.printStackTrace();
//                }
//            }
//            return st.nextToken();
//        }
//
//        int nextInt()
//        {
//            return Integer.parseInt(next());
//        }
//
//        boolean hasNext()
//        {
//            return next()!=null;
//        }
//
//        String nextLine()
//        {
//            String str = "";
//
//            try
//            {
//                str = br.readLine();
//            }
//            catch(IOException e)
//            {
//                e.printStackTrace();
//            }
//            return str;
//        }
//    }
//
//    static class Reader
//    {
//        final private int BUFFER_SIZE = 1 << 16;
//        private DataInputStream din;
//        private byte[] buffer;
//        private int bufferPointer, bytesRead;
//
//        public Reader()
//        {
//            din = new DataInputStream(System.in);
//            buffer = new byte[BUFFER_SIZE];
//            bufferPointer = bytesRead = 0;
//        }
//
//        public Reader(String file_name) throws IOException
//        {
//            din = new DataInputStream(new FileInputStream(file_name));
//            buffer = new byte[BUFFER_SIZE];
//            bufferPointer = bytesRead = 0;
//        }
//
//        public String readLine() throws IOException
//        {
//            byte[] buf = new byte[100001]; // line length
//            int cnt = 0, c;
//            while ((c = read()) != -1)
//            {
//                if (c == '\n')
//                    break;
//                buf[cnt++] = (byte) c;
//            }
//            return new String(buf, 0, cnt);
//        }
//
//        public int nextInt() throws IOException
//        {
//            int ret = 0;
//            byte c = read();
//            while (c <= ' ')
//                c = read();
//            boolean neg = (c == '-');
//            if (neg)
//                c = read();
//            do
//            {
//                ret = ret * 10 + c - '0';
//            } while ((c = read()) >= '0' && c <= '9');
//
//            if (neg)
//                return -ret;
//            return ret;
//        }
//
//        public long nextLong() throws IOException
//        {
//            long ret = 0;
//            byte c = read();
//            while (c <= ' ')
//                c = read();
//            boolean neg = (c == '-');
//            if (neg)
//                c = read();
//            do {
//                ret = ret * 10 + c - '0';
//            }
//            while ((c = read()) >= '0' && c <= '9');
//            if (neg)
//                return -ret;
//            return ret;
//        }
//
//        public double nextDouble() throws IOException
//        {
//            double ret = 0, div = 1;
//            byte c = read();
//            while (c <= ' ')
//                c = read();
//            boolean neg = (c == '-');
//            if (neg)
//                c = read();
//
//            do {
//                ret = ret * 10 + c - '0';
//            }
//            while ((c = read()) >= '0' && c <= '9');
//
//            if (c == '.')
//            {
//                while ((c = read()) >= '0' && c <= '9')
//                {
//                    ret += (c - '0') / (div *= 10);
//                }
//            }
//
//            if (neg)
//                return -ret;
//            return ret;
//        }
//
//        private void fillBuffer() throws IOException
//        {
//            bytesRead = din.read(buffer, bufferPointer = 0, BUFFER_SIZE);
//            if (bytesRead == -1)
//                buffer[0] = -1;
//        }
//
//        private byte read() throws IOException
//        {
//            if (bufferPointer == bytesRead)
//                fillBuffer();
//            return buffer[bufferPointer++];
//        }
//
//        public void close() throws IOException
//        {
//            if (din == null)
//                return;
//            din.close();
//        }
//    }
//
//    static long MOD = (long) (1e9 + 7);
//    static int size = (int)(5e5+5);
//    static long[] arr1 = new long[size];
//
//    static long powerLL(long x, long n)
//    {
//        long result = 1;
//        while (n > 0)
//        {
//            if (n % 2 == 1)
//            {
//                result = result * x % MOD;
//            }
//            n = n / 2;
//            x = x * x % MOD;
//        }
//        return result;
//    }
//
//    static long powerStrings(String sa, String sb)
//    {
//        long a = 0, b = 0;
//
//        for (int i = 0; i < sa.length(); i++)
//        {
//            a = (a * 10 + (sa.charAt(i) - '0')) %
//                    MOD;
//        }
//
//        for (int i = 0; i < sb.length(); i++)
//        {
//            b = (b * 10 + (sb.charAt(i) - '0')) %
//                    (MOD - 1);
//        }
//
//        return powerLL(a, b);
//    }
//
//    static String subb(String s)
//    {
//        String res = "";
//        char mx = s.charAt(0);
//
//
//        for (int i = 1; i < s.length(); i++)
//            mx = (char)Math.max((int)mx,
//                    (int)s.charAt(i));
//
//        for (int i = 0; i < s.length(); i++)
//            if (s.charAt(i) == mx)
//                res += s.charAt(i);
//
//        return res;
//    }
//
//    public static void main(String[] args) throws java.lang.Exception
//    {
//        try
//        {
//           FastReader fr = new FastReader();
//         //   Reader fr = new Reader();
//            PrintWriter out = new PrintWriter(System.out);
//
//            int n = fr.nextInt();
//
//            String[] str = new String[n];
//            for (int i=0;i<n;i++) str[i] = fr.nextLine();
//
//            int ans = 10;
//
//            char[] temp_arr = {'R','G','B','Y','W','1','2'.'3'.'4','5'};
//            for (int i=0;i<(1<<10);i++;i++)
//            {
//                HashSet<Character> hs = new HashSet<>();
//
//                for (int j = 0; j < 10; j++) {
//                    if ((i & (1 << i)) != 0) hs.add(temp_arr[i]);
//                }
//
//
//                boolean ff = true;
//
//                for (int j = 0; j < n && ff; j++)
//                {
//                    for (int k = i; k < n; k++)
//                    {
//                        if (str[j].equals(str[k]) == false) {
//                            char c1 = str[j].charAt(0);
//                            char c2 = str[k].charAt(0);
//
//                            if (c1 != c2 && (hs.contains(c1) || hs.contains(c2))) continue;
//
//                            char c3 = str[j].charAt(1);
//                            char c4 = str[k].charAt(1);
//
//                            if (c3!=c4 && (hs.contains(c3)|| hs.contains(c4))) continue;
//
//                            ff = false;
//                            break;
//                        }
//                    }
//                }
//
//                if (ff) ans = Math.min(hs.size(),ans);
//
//                System.out.println(ans);
//            }
//
//        }
//
//        catch(Exception e){e.printStackTrace();}
//        finally{}
//    }
//}
///*
//4
//14
//8
//3
//17
//4
//11
// */