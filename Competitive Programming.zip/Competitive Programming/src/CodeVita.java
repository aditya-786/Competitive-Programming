import java.util.*;
import java.io.*;

public class CodeVita {

    static class FastReader
    {
        BufferedReader br;
        StringTokenizer st;

        public FastReader()
        {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        String next()
        {
            while(st==null || !st.hasMoreElements())
            {
                try
                {
                    st = new StringTokenizer(br.readLine());
                }
                catch(IOException e)
                {
                    e.printStackTrace();
                }
            }
            return st.nextToken();
        }

        int nextInt()
        {
            return Integer.parseInt(next());
        }

        String nextLine()
        {
            String str = "";

            try
            {
                str = br.readLine();
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return str;
        }
    }

    static class Reader
    {
        final private int BUFFER_SIZE = 1 << 16;
        private DataInputStream din;
        private byte[] buffer;
        private int bufferPointer, bytesRead;

        public Reader()
        {
            din = new DataInputStream(System.in);
            buffer = new byte[BUFFER_SIZE];
            bufferPointer = bytesRead = 0;
        }

        public Reader(String file_name) throws IOException
        {
            din = new DataInputStream(new FileInputStream(file_name));
            buffer = new byte[BUFFER_SIZE];
            bufferPointer = bytesRead = 0;
        }

        public String readLine() throws IOException
        {
            byte[] buf = new byte[1001]; // line length
            int cnt = 0, c;
            while ((c = read()) != -1)
            {
                if (c == '\n')
                    break;
                buf[cnt++] = (byte) c;
            }
            return new String(buf, 0, cnt);
        }

        public int nextInt() throws IOException
        {
            int ret = 0;
            byte c = read();
            while (c <= ' ')
                c = read();
            boolean neg = (c == '-');
            if (neg)
                c = read();
            do
            {
                ret = ret * 10 + c - '0';
            } while ((c = read()) >= '0' && c <= '9');

            if (neg)
                return -ret;
            return ret;
        }

        public long nextLong() throws IOException
        {
            long ret = 0;
            byte c = read();
            while (c <= ' ')
                c = read();
            boolean neg = (c == '-');
            if (neg)
                c = read();
            do {
                ret = ret * 10 + c - '0';
            }
            while ((c = read()) >= '0' && c <= '9');
            if (neg)
                return -ret;
            return ret;
        }

        public double nextDouble() throws IOException
        {
            double ret = 0, div = 1;
            byte c = read();
            while (c <= ' ')
                c = read();
            boolean neg = (c == '-');
            if (neg)
                c = read();

            do {
                ret = ret * 10 + c - '0';
            }
            while ((c = read()) >= '0' && c <= '9');

            if (c == '.')
            {
                while ((c = read()) >= '0' && c <= '9')
                {
                    ret += (c - '0') / (div *= 10);
                }
            }

            if (neg)
                return -ret;
            return ret;
        }

        private void fillBuffer() throws IOException
        {
            bytesRead = din.read(buffer, bufferPointer = 0, BUFFER_SIZE);
            if (bytesRead == -1)
                buffer[0] = -1;
        }

        private byte read() throws IOException
        {
            if (bufferPointer == bytesRead)
                fillBuffer();
            return buffer[bufferPointer++];
        }

        public void close() throws IOException
        {
            if (din == null)
                return;
            din.close();
        }
    }

    static boolean checkPalindrome(String s)
    {
        int n = s.length();

        if (n==1) return true;

        for (int i=0;i<n/2;i++) if (s.charAt(i)!=s.charAt(n-1-i)) return false;
        return true;
    }

    static void finalAnswer(String s)
    {
        for(int i=1;i<s.length()-2;i++)
        {
            if (checkPalindrome(s.substring(0,i)))
            {
                for (int j=i+1;j<s.length();j++)
                {
                    if (checkPalindrome(s.substring(i,j)) && checkPalindrome(s.substring(j,s.length()) ) )
                    {
                        System.out.println(s.substring(0,i));
                        System.out.println(s.substring(i,j));
                        System.out.println(s.substring(j,s.length()));
//                        out.flush();
//                        out.close();
                        return;
                    }
                }
            }
        }

        System.out.println("Impossible");
    }

    public static void main(String[] args) throws java.lang.Exception
    {
        try
        {
            FastReader fr = new FastReader();
            //Reader fr = new Reader();
           PrintWriter out = new PrintWriter(System.out);

           int hcost = fr.nextInt();
           int ccost = fr.nextInt();
           int acost = fr.nextInt();

           int harea = fr.nextInt();
           int carea = fr.nextInt();
           int aarea = fr.nextInt();

           int minh = fr.nextInt();
           int maxh = fr.nextInt();

           int minc =  fr.nextInt();
           int maxc = fr.nextInt();

           int mina = fr.nextInt();
           int maxa = fr.nextInt();

           int totalArea = fr.nextInt();

           int tt = Math.min(Math.min(hcost,ccost),acost);

           int ans1, ans2, ele1, ele2;

           if (tt == hcost)
           {
               ans1 = harea * tt;
               ele1 = harea;
           }
           else if (tt == ccost)
           {
               ans1 = carea * tt;
               ele1 = carea;
           }
           else
           {
               ans1 = aarea * tt;
               ele1 = aarea;
           }

           tt = Math.max(Math.max(hcost,ccost),acost);

           if (tt == hcost)
           {
               ans2 = minh * maxh * hcost;
               ele2 = minh * maxh;
           }
           else if (tt == ccost)
           {
               ans2 = minc * maxc * ccost;
               ele2 = minc * maxc;
           }
           else
           {
               ans2 = mina * maxa * acost;
               ele2 = mina * maxa;
           }

           int raw = totalArea - (ele1 + ele2);

           List<Integer> list = new ArrayList<>();
           list.add(hcost);
           list.add(ccost);
           list.add(acost);
           Collections.sort(list);

           int ans3 = raw * list.get(1);

           out.println(ans1+ans2+ans3);

           out.flush();
           out.close();
        }

        catch(Exception e){e.printStackTrace();}
        finally{}
    }
}
